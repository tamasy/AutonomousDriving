#!/usr/bin/env python3
"""
Pure Pursuit パラメータ Optuna 自動調整スクリプト

使い方 (Docker コンテナ内で実行):
    python3 /aichallenge/workspace/src/aichallenge_submit/aichallenge_submit_launch/scripts/optimize_pure_pursuit.py

オプション:
    --n-trials N       トライアル数 (デフォルト: DEFAULT_N_TRIALS)
    --timeout SEC      シミュレーション1回あたりのタイムアウト秒 (デフォルト: reference.launch.xml の optuna_trial_timeout)
    --study-db PATH    Optuna DB パス (デフォルト: DEFAULT_STUDY_DB)
    --resume           既存スタディを再開する
    --dry-run          シミュレーションを実行せずパラメータ書き込みのみ確認
    --restore-defaults reference.launch.xml をデフォルト値 + control_mode=mpc に戻して終了

注意:
    最適化実行中は control_mode を自動的に rule_based に切り替えます。
    終了後は元の control_mode に復元します。
    実行開始時に reference.launch.xml を /output/ にタイムスタンプ付きでバックアップします。
"""

import argparse
import json
import math
import os
import re
import select
import shutil
import subprocess
import sys
import threading
import time
from datetime import datetime
from pathlib import Path

# ============================================================
# パス設定 (Docker コンテナ内のパス)
# ============================================================
LAUNCH_XML_PATH = Path(
    "/aichallenge/workspace/src/aichallenge_submit"
    "/aichallenge_submit_launch/launch/reference.launch.xml"
)
OUTPUT_DIR = Path("/output")
TRIAL_LOG_PATH = OUTPUT_DIR / "optuna_trials.csv"
RUN_EVALUATION_CMD = "/aichallenge/run_evaluation.bash"
RESULT_CONVERTER_CMD = Path(
    "/aichallenge/workspace/src/aichallenge_system/script/result-converter.py"
)
POSITION_TOPIC = "/localization/kinematic_state"

DEFAULT_STUDY_DB    = "sqlite:////aichallenge/workspace/pure_pursuit_study.db"

# ============================================================
# Sim.実行設定
# ============================================================
DEFAULT_N_TRIALS    = 100    # トライアル数

# ---- Sim.開始待機 ----
AWSIM_INIT_WAIT_SEC = 45    # AWSIM 起動完了を待つ秒数

# ---- トライアル終了条件 ----
DEFAULT_TRIAL_TIMEOUT    = 60    # Optunaの1トライアルあたりのタイムアウト秒 (AWSIM フリーズ時の安全上限)
STUCK_SPEED_KMH          = 1.2   # この速度以下が続いたらスタック判定 [km/h]
STUCK_DURATION_SEC       = 5.0   # スタック判定の継続秒数 [s]
TARGET_LAPS              = 1     # Optunaの1トライアルあたりの終了周回数 (0=無制限)

# ---- 周回検知パラメータ ----
# ✅スタートライン座標     (None の場合は最初の位置取得時に動的に記録)
LAP_START_POS: "tuple[float, float] | None" = (89633.29, 43127.57)
# ✅スタートライン法線方向 (None の場合は LAP_MIN_AWAY_DISTANCE_M 離れた時点で動的計算)
# publish_initialpose.py の初期クォータニオン (z=0.8778, w=0.4788) から計算:
#   yaw         = 2*atan2(0.8778, 0.4788) ≈ 2.143 rad
#   forward     = (cos(2.143), sin(2.143)) ≈ (-0.540, 0.842)
LAP_DEPARTURE_DIR: "tuple[float, float] | None" = (-0.540, 0.842)
# ✅スタート位置からこの距離 [m] 以上離れた後に「出発した」とみなす
# LAP_DEPARTURE_DIR=None の場合のみ使用 (動的出発判定)
LAP_MIN_AWAY_DISTANCE_M     = 20.0
# ✅周回完了判定するスタートライン停止オフセット [m] (-20.0 ～ +20.0 程度を想定)
LAP_STOP_OFFSET_M           = 10.0

# ============================================================
# ▼▼▼ 調整可能な設定パラメータ (ここを編集してください) ▼▼▼
# ============================================================
# ---- Pure Pursuit パラメータ探索範囲 ----
# ---- デフォルト値（ベースライン・--restore-defaults 用） ----
PARAM_DEFAULTS = {
    "lookahead_gain":           0.5014,
    "lookahead_min_distance":   3.5013,
    "speed_proportional_gain":  1.0448,
    "steering_tire_angle_gain": 1.4658,
}
# ---- 探索範囲 (optuna_trial_timeout 内に完走できる範囲に絞ることを推奨) ----
PARAM_RANGES = {
    "lookahead_gain":           (0.400,  0.600),
    "lookahead_min_distance":   (2.000,  6.000),
    "speed_proportional_gain":  (0.950,  1.100),
    "steering_tire_angle_gain": (1.350,  1.550),
}
"""
PARAM_RANGES = {
# Sim.動作確認用に狭い範囲でテストする場合の例
    "lookahead_gain":           (0.500,  0.502),    # デフォルト: 0.5
    "lookahead_min_distance":   (3.500,  3.502),    # デフォルト: 3.5
    "speed_proportional_gain":  (1.044,  1.050),    # デフォルト: 1.0
    "steering_tire_angle_gain": (1.465,  1.466),    # デフォルト: 1.5
}
"""

# ============================================================
# ▲▲▲ 調整可能な設定パラメータ ここまで ▲▲▲
# ============================================================


# ============================================================
# XML 操作
# ============================================================

def read_xml() -> str:
    return LAUNCH_XML_PATH.read_text(encoding="utf-8")


def write_xml(content: str) -> None:
    LAUNCH_XML_PATH.write_text(content, encoding="utf-8")


def _replace_param_in_section(section: str, param_name: str, value: float) -> str:
    """section 内の <param name="param_name" ... value="..."/> を置換する"""
    pattern = rf'(<param\s+name="{re.escape(param_name)}"[^/]*?value=")[^"]*(")'
    replaced, n = re.subn(pattern, rf'\g<1>{value:.4f}\g<2>', section)
    if n == 0:
        raise ValueError(f"パラメータ '{param_name}' が見つかりませんでした。")
    return replaced


def set_param_in_xml(content: str, param_name: str, value: float) -> str:
    """
    simple_pure_pursuit_node セクション内のパラメータだけを置換する。
    MPC など他のノードの同名パラメータは変更しない。
    """
    node_pattern = r'(<node[^>]+name="simple_pure_pursuit_node".*?</node>)'
    node_match = re.search(node_pattern, content, re.DOTALL)
    if not node_match:
        raise ValueError("simple_pure_pursuit_node が XML に見つかりませんでした。")
    new_node = _replace_param_in_section(node_match.group(1), param_name, value)
    return content[:node_match.start()] + new_node + content[node_match.end():]


def get_control_mode(content: str) -> str:
    """現在の control_mode デフォルト値を取得する"""
    m = re.search(r'<arg\s+name="control_mode"\s+default="([^"]*)"', content)
    return m.group(1) if m else "mpc"


def set_control_mode(content: str, mode: str) -> str:
    """control_mode のデフォルト値を変更する"""
    pattern = r'(<arg\s+name="control_mode"\s+default=")[^"]*(")'
    replaced, n = re.subn(pattern, rf'\g<1>{mode}\g<2>', content)
    if n == 0:
        raise ValueError("control_mode 引数が XML に見つかりませんでした。")
    return replaced


def write_params(params: dict) -> None:
    """Pure Pursuit パラメータを simple_pure_pursuit_node セクションにのみ書き込む"""
    content = read_xml()
    for name, value in params.items():
        content = set_param_in_xml(content, name, value)
    write_xml(content)
    print(f"[Optuna] reference.launch.xml を更新しました (simple_pure_pursuit_node のみ):")
    for k, v in params.items():
        print(f"  {k}: {v:.4f}")


def restore_defaults() -> None:
    """デフォルト値 + control_mode=mpc に復元する"""
    content = read_xml()
    for name, value in PARAM_DEFAULTS.items():
        content = set_param_in_xml(content, name, value)
    content = set_control_mode(content, "mpc")
    write_xml(content)
    print("[Optuna] デフォルトパラメータ + control_mode=mpc を復元しました。")


# ============================================================
# シミュレーション実行
# ============================================================

def _is_process_running(pattern: str) -> bool:
    """指定パターンのプロセスが存在するか確認する"""
    return subprocess.run(["pgrep", "-f", pattern], capture_output=True).returncode == 0


def cleanup_processes() -> None:
    """AWSIM / Autoware の残プロセスをクリーンアップする"""
    print("[Optuna] 残プロセスをクリーンアップ中...")

    # 1. まず AWSIM に SIGTERM を送る
    #    Unity の OnApplicationQuit() が呼ばれ result-details.json が書かれる
    awsim_was_running = _is_process_running("AWSIM.x86_64")
    subprocess.run(["pkill", "-f", "AWSIM.x86_64"], capture_output=True)
    subprocess.run(["pkill", "-f", "run_simulator.bash"], capture_output=True)

    # 2. AWSIM が結果ファイルを書き出す時間を確保
    #    AWSIM が起動中だった場合のみ待機（起動していない場合はスキップ）
    if awsim_was_running:
        print("[Optuna] AWSIM の終了を待機中 (15s) ...")
        time.sleep(15)
    else:
        print("[Optuna] AWSIM は未起動でした。待機をスキップします。")

    # 3. Autoware の全ノードを kill
    #    pkill -f "aichallenge_system.launch" は ros2 launch プロセス本体のみ殺す。
    #    子プロセス (component_container, ros2 run 等) は別途 kill が必要。
    #    rviz2 / control_mode_adapter は ros2 run 経由ではなく直接起動されるため個別指定。
    autoware_patterns = [
        "aichallenge_system.launch",
        "run_autoware.bash",
        "component_container",
        "ros2 run",
        "ros2 launch",
        "rviz2",
        "control_mode_adapter",
    ]
    for pattern in autoware_patterns:
        subprocess.run(["pkill", "-f", pattern], capture_output=True)

    # 4. Autoware プロセスの完全終了を pgrep で確認（最大30秒）
    check_patterns = ["component_container", "ros2 run", "ros2 launch", "rviz2", "control_mode_adapter"]
    deadline = time.time() + 30
    while time.time() < deadline:
        if not any(_is_process_running(p) for p in check_patterns):
            break
        time.sleep(2)
    else:
        print("[Optuna] 警告: Autoware プロセスが30秒以内に終了しませんでした。SIGKILL を送ります。")
        for pattern in check_patterns:
            subprocess.run(["pkill", "-9", "-f", pattern], capture_output=True)
        time.sleep(3)

    # 5. ROS2 daemon と Fast-DDS 共有メモリをリセット
    #    SIGKILL で死んだプロセスは DDS の "farewell" を送れないため ghost participant が蓄積し、
    #    TRANSIENT_LOCAL キャッシュ経由で古い制御コマンドが次トライアルに配信される。
    #    daemon 停止 + shm 削除でトライアル間の DDS 汚染を防ぐ。
    print("[Optuna] ROS2 daemon / Fast-DDS 共有メモリをリセット中...")
    try:
        subprocess.run(["ros2", "daemon", "stop"], capture_output=True, timeout=5)
    except subprocess.TimeoutExpired:
        pass
    subprocess.run(
        "rm -f /dev/shm/fast* /dev/shm/fastrtps* 2>/dev/null || true",
        shell=True, capture_output=True,
    )

    print("[Optuna] クリーンアップ完了。")
    _log_remaining_processes()


def _log_remaining_processes() -> None:
    """クリーンアップ後に残存する関連プロセスを診断ログとして出力する"""
    patterns = [
        "AWSIM.x86_64",
        "run_simulator.bash",
        "run_autoware.bash",
        "run_evaluation.bash",
        "aichallenge_system.launch",
        "component_container",
        "ros2 launch",
        "ros2 run",
        "rviz2",
        "control_mode_adapter",
    ]
    my_pid = os.getpid()
    print("[Optuna][診断] クリーンアップ後の残存プロセス確認:")
    found_any = False
    for pattern in patterns:
        result = subprocess.run(
            ["pgrep", "-a", "-f", pattern],
            capture_output=True, text=True,
        )
        for line in result.stdout.strip().splitlines():
            parts = line.split(None, 1)
            if parts and parts[0].isdigit() and int(parts[0]) == my_pid:
                continue
            print(f"[Optuna][診断]   残存: {line}")
            found_any = True
    if not found_any:
        print("[Optuna][診断]   残存プロセスなし (正常)")

    try:
        r = subprocess.run(
            ["ros2", "node", "list"],
            capture_output=True, text=True, timeout=8,
        )
        nodes = [n for n in r.stdout.strip().splitlines() if n.strip()]
        if nodes:
            print(f"[Optuna][診断] 残存 ROS2 ノード ({len(nodes)} 件)")
        else:
            print("[Optuna][診断] 残存 ROS2 ノード: なし (正常)")
    except subprocess.TimeoutExpired:
        print("[Optuna][診断] ros2 node list タイムアウト (ROS2 デーモン不安定の可能性あり)")
    except FileNotFoundError:
        pass  # ros2 コマンドが見つからない環境では無視


def _get_position() -> "tuple[float, float] | None":
    """
    /localization/kinematic_state から現在位置 (x, y) [m] を取得する。
    取得失敗 (トピック未発行・タイムアウト) 時は None を返す。
    """
    try:
        r = subprocess.run(
            ["ros2", "topic", "echo", "--once", "--no-arr", POSITION_TOPIC],
            capture_output=True, text=True, timeout=3,
        )
        in_position = False
        pos_x = pos_y = None
        for line in r.stdout.split("\n"):
            stripped = line.strip()
            if stripped == "position:":
                in_position = True
                continue
            if in_position:
                if stripped.startswith("x:"):
                    try:
                        pos_x = float(stripped.split(":", 1)[1].strip())
                    except ValueError:
                        pass
                elif stripped.startswith("y:"):
                    try:
                        pos_y = float(stripped.split(":", 1)[1].strip())
                    except ValueError:
                        pass
                if pos_x is not None and pos_y is not None:
                    return pos_x, pos_y
                if stripped and not stripped.startswith(("x:", "y:", "z:")):
                    in_position = False
    except Exception:
        pass
    return None


def _monitor_laps(
    stop_event: threading.Event,
    laps_reached_event: threading.Event,
    target_laps: int,
) -> None:
    """
    /localization/kinematic_state を 1 秒ごとにポーリングし、所定周回到達で laps_reached_event をセット。

    proj = dot(car_pos - start_pos, departure_dir) の符号と変化方向:
      出発直後:  proj ≈ 0 → 正に増加 (車が出発方向へ進む)
      周回中盤:  proj は大きく負になる (コース裏側)
      帰還時:    proj が負から 0 方向へ増加しながらフィニッシュラインを横断
                 → proj が LAP_STOP_OFFSET_M を「下から上」に横切った瞬間を検知

    ロジック:
      1. スタート位置から LAP_MIN_AWAY_DISTANCE_M 以上離れたら「出発した」と判定
         (LAP_DEPARTURE_DIR 固定時も Euclidean 距離で判定)
      2. 出発後、proj < (LAP_STOP_OFFSET_M - LAP_MIN_AWAY_DISTANCE_M) になったら「帰還ゾーン」に入ったと判定
         (コース裏側まで行ったことを確認し、出発直後の誤検知を防ぐ)
      3. 帰還ゾーン内で prev_proj < LAP_STOP_OFFSET_M <= proj を検知したら周回完了
         LAP_STOP_OFFSET_M > 0: フィニッシュラインをこの距離 [m] 通過後に完了
         LAP_STOP_OFFSET_M = 0: フィニッシュライン上で完了
         LAP_STOP_OFFSET_M < 0: フィニッシュラインのこの距離 [m] 手前で完了
      4. target_laps 周完了で laps_reached_event をセット
    """
    # LAP_START_POS が設定されていれば固定座標を使用、なければ動的に取得
    start_pos: "tuple[float, float] | None" = LAP_START_POS
    # LAP_DEPARTURE_DIR が設定されていれば固定方向を使用、なければ動的に計算
    departure_dir: "tuple[float, float] | None" = LAP_DEPARTURE_DIR
    lap_count = 0
    moved_away = False      # dist >= LAP_MIN_AWAY_DISTANCE_M に達したか
    in_return_zone = False  # 帰還ゾーン (proj < return_zone_threshold) に入ったか
    prev_proj: "float | None" = None

    # 帰還ゾーン閾値: この proj を下回ったら「コース裏側まで行った」とみなす
    # LAP_STOP_OFFSET_M から LAP_MIN_AWAY_DISTANCE_M だけ手前に設定
    return_zone_threshold = LAP_STOP_OFFSET_M - LAP_MIN_AWAY_DISTANCE_M

    # 使うときの備忘録
    if LAP_STOP_OFFSET_M >= 0:
        #offset_desc = f"+{LAP_STOP_OFFSET_M:.1f}m ({LAP_STOP_OFFSET_M:.1f}m通過後)"
        offset_desc = f"+{LAP_STOP_OFFSET_M:.1f}m"
    else:
        #offset_desc = f"{LAP_STOP_OFFSET_M:.1f}m ({abs(LAP_STOP_OFFSET_M):.1f}m手前)"
        offset_desc = f"{LAP_STOP_OFFSET_M:.1f}m"
    
    dir_mode = "固定" if LAP_DEPARTURE_DIR is not None else f"動的 (出発判定: {LAP_MIN_AWAY_DISTANCE_M:.0f}m)"
    print(
        f"[Optuna] 周回監視開始 "
        f"("
        f"スタート位置:({start_pos[0]:.2f}, {start_pos[1]:.2f}), "
        f"周回完了位置:{offset_desc}"
        f")"
    )
    """
        # 使うときの備忘録
        f"目標: {target_laps}周, "
        f"方向: {dir_mode}, "
        f"帰還ゾーン閾値: {return_zone_threshold:.1f}m"
    if start_pos is not None:
        print(f"[Optuna] 周回監視: スタート位置 (固定) ({start_pos[0]:.2f}, {start_pos[1]:.2f})")
    if departure_dir is not None:
        print(f"[Optuna] 周回監視: 出発方向 (固定) ({departure_dir[0]:.3f}, {departure_dir[1]:.3f})")
    """

    while not stop_event.is_set() and not laps_reached_event.is_set():
        pos = _get_position()
        if pos is not None:
            x, y = pos
            if start_pos is None:
                start_pos = (x, y)
                print(f"[Optuna] 周回監視: スタート位置を記録 (動的) ({x:.1f}, {y:.1f})")
            else:
                dx = x - start_pos[0]
                dy = y - start_pos[1]
                dist = math.sqrt(dx ** 2 + dy ** 2)

                # 出発判定 (Euclidean 距離で判定)
                if not moved_away and dist >= LAP_MIN_AWAY_DISTANCE_M:
                    moved_away = True
                    if departure_dir is None:
                        # 動的: この時点の方向をフィニッシュライン法線として記録
                        departure_dir = (dx / dist, dy / dist)
                        # 動的計算時は出発方向への射影をそのまま使う
                        return_zone_threshold = LAP_STOP_OFFSET_M - LAP_MIN_AWAY_DISTANCE_M
                        print(
                            f"[Optuna] 周回監視: 出発確認 "
                            f"(距離: {dist:.1f}m, 出発方向(動的): ({departure_dir[0]:.3f}, {departure_dir[1]:.3f}))"
                        )
                    else:
                        print(f"[Optuna] 周回監視: 出発確認 (距離: {dist:.1f}m, 方向: 固定)")

                if moved_away and departure_dir is not None:
                    proj = dx * departure_dir[0] + dy * departure_dir[1]

                    # 帰還ゾーン判定: proj がコース裏側を示す値を下回ったか
                    if not in_return_zone and proj < return_zone_threshold:
                        in_return_zone = True
                        print(f"[Optuna] 周回監視: 帰還ゾーン到達 (proj: {proj:.1f}m)")

                    # 周回完了判定: 帰還ゾーン内で proj が LAP_STOP_OFFSET_M を下から上に横切る
                    if in_return_zone and prev_proj is not None:
                        if prev_proj < LAP_STOP_OFFSET_M <= proj:
                            lap_count += 1
                            moved_away = False
                            in_return_zone = False
                            prev_proj = None
                            print(
                                f"[Optuna] 周回完了: {lap_count}/{target_laps} 周 "
                                f"(proj: {proj:.1f}m, 直線距離: {dist:.1f}m)"
                            )
                            if lap_count >= target_laps:
                                print(f"[Optuna] 所定周回到達: {lap_count} 周完了。シミュレーションを停止します。")
                                laps_reached_event.set()
                                return
                            continue  # prev_proj の更新をスキップして次の周回の監視へ

                    prev_proj = proj
        time.sleep(1)


def _monitor_speed(
    stop_event: threading.Event,
    stuck_event: threading.Event,
    stuck_speed_mps: float,
    stuck_duration_sec: float,
) -> None:
    """
    /vehicle/status/velocity_status を購読し、スタック検知時に stuck_event をセット。

    ロジック:
      1. 一度でも stuck_speed_mps を超えたら「走行開始」とみなす (スタートアップ除外)
      2. 走行開始後、速度が stuck_speed_mps 以下の状態が stuck_duration_sec 続いたら stuck_event をセット
      3. clear_speed_mps (≥5 km/h) が CLEAR_SUSTAIN_SEC 秒以上継続した場合のみタイマーリセット
         (コーナーでの瞬間的な加速でタイマーがリセットされるのを防ぐ)

    実装上の注意:
      text=True (TextIOWrapper) は内部バッファに複数行を溜め込むため、
      select.select の "not ready" 判定が不正確になる。
      rawバイナリ fd + os.set_blocking(False) + os.read() で完全に回避する。
    """
    # ---- スタックタイマーリセットの閾値 ----
    # コーナーで一瞬だけ 1~4 km/h 出てもリセットされないよう高めに設定
    clear_speed_mps  = max(stuck_speed_mps * 5.0, 5.0 / 3.6)   # ≥5 km/h
    CLEAR_SUSTAIN_SEC = 2.0  # clear_speed_mps をこの秒数継続してはじめてタイマーリセット

    echo = subprocess.Popen(
        ["ros2", "topic", "echo", "--no-arr", "/vehicle/status/velocity_status"],
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
        # text=False (デフォルト) でバイナリモード — TextIOWrapper バッファを使わない
    )
    fd = echo.stdout.fileno()
    os.set_blocking(fd, False)   # 非ブロッキング: os.read() は即座にリターン

    print(f"[Optuna] 速度監視開始 (raw fd モード) "
          f"stuck閾値={stuck_speed_mps*3.6:.1f}km/h×{stuck_duration_sec:.0f}s "
          f"clear閾値={clear_speed_mps*3.6:.1f}km/h×{CLEAR_SUSTAIN_SEC:.0f}s")

    ever_moved        = False
    stuck_since       = None
    above_clear_since = None
    line_buf          = b""
    monitor_start     = time.time()
    # ever_moved が False でも、監視開始から startup_grace_sec 経過後は
    # スタック検知を有効化する（車両が一度も動かない場合の検知漏れを防ぐ）
    startup_grace_sec = stuck_duration_sec * 2.0

    try:
        while not stop_event.is_set() and not stuck_event.is_set():
            # 1 秒タイムアウトで待機 — メッセージが来なくてもタイマーチェックを実行できる
            ready, _, _ = select.select([echo.stdout], [], [], 1.0)

            # 検知を有効にする条件: 一度でも動いた OR 監視開始から startup_grace_sec 経過
            detection_active = ever_moved or (time.time() - monitor_start >= startup_grace_sec)

            if not ready:
                # ---- メッセージなし: タイマーだけチェック ----
                if detection_active and stuck_since is not None:
                    if time.time() - stuck_since >= stuck_duration_sec:
                        print(
                            f"[Optuna] スタック検知: {stuck_duration_sec:.0f}s"
                            f" (トピック停止 or 速度ゼロ継続)"
                        )
                        stuck_event.set()
                continue

            # ---- データあり: rawバイトを読んで行に分割 ----
            try:
                chunk = os.read(fd, 4096)
            except BlockingIOError:
                continue
            if not chunk:
                break   # echo プロセスが終了

            line_buf += chunk
            lines = line_buf.split(b"\n")
            line_buf = lines[-1]   # 末尾の不完全行を次回に持ち越す

            for raw_line in lines[:-1]:
                line = raw_line.strip().decode("utf-8", errors="ignore")
                if not line.startswith("longitudinal_velocity:"):
                    continue
                try:
                    vel = abs(float(line.split(":", 1)[1].strip()))
                except ValueError:
                    continue

                if vel >= clear_speed_mps:
                    # 高速走行中: CLEAR_SUSTAIN_SEC 秒継続したらタイマーリセット
                    ever_moved = True
                    if above_clear_since is None:
                        above_clear_since = time.time()
                    elif time.time() - above_clear_since >= CLEAR_SUSTAIN_SEC:
                        stuck_since       = None
                        above_clear_since = None
                elif vel > stuck_speed_mps:
                    # 低速だが閾値超え (1~5 km/h): ever_moved セット、タイマーは変更しない
                    ever_moved        = True
                    above_clear_since = None
                elif detection_active:
                    # 閾値以下 (<1 km/h) かつ検知有効: スタックタイマーを積み上げる
                    above_clear_since = None
                    if stuck_since is None:
                        stuck_since = time.time()
                    elif time.time() - stuck_since >= stuck_duration_sec:
                        print(
                            f"[Optuna] スタック検知: 速度 {vel * 3.6:.2f} km/h が "
                            f"{stuck_duration_sec:.0f}s 継続。"
                        )
                        stuck_event.set()
                        break   # inner for ループ脱出 → outer while 条件で脱出
                else:
                    above_clear_since = None

    except Exception as e:
        print(f"[Optuna] 速度モニタエラー: {e}")
    finally:
        echo.kill()
        echo.wait()


def _find_latest_details_json() -> "Path | None":
    """
    latest/ 以外のタイムスタンプフォルダで最近更新された result-details.json を探す。

    latest が実ディレクトリになっていて ln -nfs が失敗している場合のフォールバック。
    """
    candidates = [
        d / "result-details.json"
        for d in OUTPUT_DIR.iterdir()
        if d.is_dir() and d.name != "latest" and (d / "result-details.json").exists()
    ]
    if not candidates:
        return None
    return max(candidates, key=lambda f: f.stat().st_mtime)


def _try_convert_result() -> "Path | None":
    """
    result-summary.json が未生成の場合、result-details.json から変換を試みる。

    AWSIM に SIGTERM を送ると Unity の OnApplicationQuit() が呼ばれ、
    完走済みラップ数分のデータが result-details.json に書き出される。
    タイムアウト時に 1 周以上完走していれば有効な結果を取得できる。

    Returns:
        生成された result-summary.json の Path。見つからない/変換失敗時は None。
    """
    summary_path = OUTPUT_DIR / "latest" / "result-summary.json"
    details_path = OUTPUT_DIR / "latest" / "result-details.json"

    if summary_path.exists():
        return summary_path  # run_evaluation.bash が正常終了した場合はスキップ

    if not details_path.exists():
        # latest/ が実ディレクトリになっていて symlink 更新が失敗している場合のフォールバック
        details_path = _find_latest_details_json()
        if details_path is None:
            print("[Optuna] 警告: result-details.json が存在しません "
                  "(AWSIM が 1 周未完走の可能性)。")
            return None
        summary_path = details_path.parent / "result-summary.json"
        if summary_path.exists():
            print(f"[Optuna] 既存の result-summary.json を使用します: {summary_path}")
            return summary_path

    print("[Optuna] result-details.json → result-summary.json に変換中 ...")
    r = subprocess.run(
        [
            "python3", str(RESULT_CONVERTER_CMD), "60", "11",
            "--input", str(details_path),
            "--output", str(summary_path),
        ],
        capture_output=True,
        text=True,
    )
    if r.returncode == 0:
        print(f"[Optuna] result-summary.json の生成完了: {summary_path}")
        return summary_path
    else:
        print(f"[Optuna] 変換エラー: {r.stderr.strip()}")
        return None


def run_simulation(
    timeout_sec: int,
    stuck_speed_mps: float,
    stuck_duration_sec: float,
    target_laps: int,
) -> "tuple[Path, str, Path | None]":
    """
    シミュレーションを実行し、(result-summary.json のパス, 終了条件, トライアル出力フォルダ) を返す。

    終了条件 (いずれか早い方):
      1. run_evaluation.bash の正常終了
      2. 車速 <= stuck_speed_mps が stuck_duration_sec 秒継続 (スタック検知)
      3. timeout_sec 経過 (上限タイムアウト)
      4. target_laps 周完走 (所定周回到達) [target_laps=0 の場合は無効]

    スタック/タイムアウト/周回到達時は AWSIM に SIGTERM を送り OnApplicationQuit() で
    result-details.json を書かせてから result-summary.json に変換する。
    """
    laps_info = f"終了周回: {'無制限' if target_laps == 0 else f'{target_laps}周'}"
    print(
        f"[Optuna] シミュレーション開始 "
        f"(timeout: {timeout_sec}s,"
        f" stuck検知: {stuck_speed_mps * 3.6:.1f}km/h×{stuck_duration_sec:.0f}s, "
        f"{laps_info})"\
    )

    # run_evaluation.bash が作成するタイムスタンプフォルダを特定するためのスナップショット
    existing_dirs = {
        d.name for d in OUTPUT_DIR.iterdir()
        if d.is_dir() and d.name != "latest"
    }

    stop_event = threading.Event()
    stuck_event = threading.Event()
    laps_reached_event = threading.Event()

    monitor_thread = threading.Thread(
        target=_monitor_speed,
        args=(stop_event, stuck_event, stuck_speed_mps, stuck_duration_sec),
        daemon=True,
    )
    lap_monitor_thread: "threading.Thread | None" = None
    if target_laps > 0:
        lap_monitor_thread = threading.Thread(
            target=_monitor_laps,
            args=(stop_event, laps_reached_event, target_laps),
            daemon=True,
        )
    # 各スレッドは AWSIM 初期化後に起動する（起動前に ros2 topic echo を開始すると
    # トピックが存在しない状態が続き DDS 接続に失敗してスレッドが無音終了するため）

    proc = None
    reason = None
    try:
        proc = subprocess.Popen([RUN_EVALUATION_CMD])
        print(f"[Optuna] AWSIM 初期化待機中 ({AWSIM_INIT_WAIT_SEC}s) ...")
        time.sleep(AWSIM_INIT_WAIT_SEC)
        monitor_thread.start()          # AWSIM 初期化完了後にスタック監視を開始
        if lap_monitor_thread:
            lap_monitor_thread.start()  # AWSIM 初期化完了後に周回監視を開始
        start = time.time()

        while True:
            if proc.poll() is not None:
                # 正常終了 (run_evaluation.bash が自力で result-summary.json を生成済み)
                break
            if stuck_event.is_set():
                reason = "スタック検知"
                proc.kill()
                break
            if laps_reached_event.is_set():
                reason = f"所定周回到達 ({target_laps}周)"
                proc.kill()
                break
            if time.time() - start >= timeout_sec:
                reason = f"上限タイムアウト ({timeout_sec}s)"
                proc.kill()
                break
            time.sleep(0.5)

    except Exception as e:
        print(f"[Optuna] 警告: シミュレーション実行エラー: {e}")
        if proc:
            proc.kill()
        reason = "例外"
    finally:
        stop_event.set()
        if monitor_thread.is_alive():
            monitor_thread.join(timeout=5)
        if lap_monitor_thread and lap_monitor_thread.is_alive():
            lap_monitor_thread.join(timeout=5)

    end_condition = reason if reason else "走行完了"

    if reason:
        print(f"[Optuna] 警告: {reason} によりシミュレーションを終了します。")
        cleanup_processes()
        # AWSIM の OnApplicationQuit() で書かれた result-details.json から変換を試みる
        result_path = _try_convert_result()
    else:
        cleanup_processes()
        result_path = None

    # run_evaluation.bash が作成した新しいタイムスタンプフォルダを特定する
    new_dirs = [
        d for d in OUTPUT_DIR.iterdir()
        if d.is_dir() and d.name != "latest" and d.name not in existing_dirs
    ]
    trial_dir: "Path | None" = (
        max(new_dirs, key=lambda d: d.stat().st_mtime) if new_dirs else None
    )
    if trial_dir:
        print(f"[Optuna] トライアル出力フォルダ: {trial_dir}")

    # result-summary.json のパスを決定 (trial_dir 優先、なければ latest/)
    if result_path is None:
        if trial_dir and (trial_dir / "result-summary.json").exists():
            result_path = trial_dir / "result-summary.json"
        else:
            result_path = OUTPUT_DIR / "latest" / "result-summary.json"
    return result_path, end_condition, trial_dir


def read_result(result_path: Path) -> dict:
    if not result_path.exists():
        print(f"[Optuna] 警告: 結果ファイルが見つかりません: {result_path}")
        return {"num_laps": 0, "min_time": None}
    with open(result_path) as f:
        return json.load(f)


def save_trial_log(
    trial_number: int,
    params: dict,
    end_condition: str,
    num_laps: int,
    min_time,
    objective_value: float,
) -> None:
    """トライアル結果を /output/optuna_trials.csv に追記する"""
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    param_names = list(PARAM_RANGES.keys())
    header_fields = ["trial", "end_condition"] + param_names + ["laps", "min_time", "objective"]
    write_header = not TRIAL_LOG_PATH.exists()

    with open(TRIAL_LOG_PATH, "a", encoding="utf-8") as f:
        if write_header:
            f.write(",".join(header_fields) + "\n")
        param_values = [f"{params[k]:.4f}" for k in param_names]
        row = (
            [str(trial_number), end_condition]
            + param_values
            + [str(num_laps), str(min_time) if min_time is not None else "", f"{objective_value:.3f}"]
        )
        f.write(",".join(row) + "\n")
    print(f"[Optuna] トライアル結果を保存しました: {TRIAL_LOG_PATH}")


# ============================================================
# Optuna 目的関数
# ============================================================

def build_objective(
    timeout_sec: int,
    stuck_speed_mps: float,
    stuck_duration_sec: float,
    target_laps: int,
    dry_run: bool,
):
    import optuna

    def objective(trial: optuna.Trial) -> float:
        params = {
            name: trial.suggest_float(name, lo, hi)
            for name, (lo, hi) in PARAM_RANGES.items()
        }

        # ---- DDS ドメイン分離 ----
        # トライアルごとに一意な ROS_DOMAIN_ID を設定する。
        # SIGKILL で死んだプロセスは DDS の "farewell" を送れないため、
        # ghost participant が蓄積して前トライアルの制御コマンドが
        # TRANSIENT_LOCAL キャッシュ経由で配信される問題を根本的に防ぐ。
        trial_domain = trial.number % 233  # ROS_DOMAIN_ID の有効範囲 0-232
        os.environ["ROS_DOMAIN_ID"] = str(trial_domain)

        # ---- トライアル開始バナー ----
        print()
        print("=" * 62)
        print(f"  ● トライアル {trial.number} を開始します  (ROS_DOMAIN_ID={trial_domain})")
        print("=" * 62)

        write_params(params)

        if dry_run:
            print("[Optuna] --dry-run モード: シミュレーションをスキップします。")
            return 0.0

        result_path, end_condition, trial_dir = run_simulation(
            timeout_sec, stuck_speed_mps, stuck_duration_sec, target_laps
        )
        result = read_result(result_path)

        num_laps = result.get("num_laps", 0)
        min_time = result.get("min_time", None)
        objective_value = 9999.0 if (num_laps == 0 or min_time is None) else float(min_time)

        print(
            f"[Optuna] Trial {trial.number}: "
            f"laps={num_laps}, min_time={min_time}, objective={objective_value:.3f}"
        )
        save_trial_log(trial.number, params, end_condition, num_laps, min_time, objective_value)

        # ---- トライアル出力フォルダに設定ファイルを保存 ----
        if trial_dir is not None:
            shutil.copy2(LAUNCH_XML_PATH, trial_dir / "reference.launch.xml")
            (trial_dir / f"ROS_DOMAIN_ID={trial_domain}").touch()
            print(f"[Optuna] 設定ファイルを保存しました: {trial_dir}")

        # ---- トライアル終了バナー ----
        print(f"  ● トライアル {trial.number} 終了  [終了条件: {end_condition}]")
        print("=" * 62)
        print()

        return objective_value

    return objective


# ============================================================
# メイン
# ============================================================

def main() -> None:
    parser = argparse.ArgumentParser(description="Pure Pursuit Optuna 自動調整")
    parser.add_argument("--n-trials", type=int, default=DEFAULT_N_TRIALS, help="トライアル数")
    parser.add_argument("--timeout", type=int, default=None,
                        help="シミュレーション1回あたりのタイムアウト秒 (省略時は reference.launch.xml の optuna_trial_timeout を使用)")
    parser.add_argument("--target-laps", type=int, default=None,
                        help="終了周回数 (省略時は reference.launch.xml の optuna_target_laps を使用, 0=無制限)")
    parser.add_argument("--study-db", default=DEFAULT_STUDY_DB,
                        help="Optuna スタディの SQLite DB パス")
    parser.add_argument("--resume", action="store_true", help="既存スタディを再開する")
    parser.add_argument("--dry-run", action="store_true",
                        help="シミュレーションを実行せずパラメータ書き込みのみ確認")
    parser.add_argument("--restore-defaults", action="store_true",
                        help="reference.launch.xml をデフォルト値 + control_mode=mpc に戻す")
    args = parser.parse_args()

    if args.restore_defaults:
        restore_defaults()
        return

    # ---- 起動前クリーンアップ（前回の中断等で残ったプロセスを除去）----
    print("[Optuna] 起動前クリーンアップを実行します...")
    cleanup_processes()

    try:
        import optuna
    except ImportError:
        print("エラー: optuna がインストールされていません。\n  pip install optuna")
        sys.exit(1)

    optuna.logging.set_verbosity(optuna.logging.WARNING)

    # ---- 実行パラメータを確定する (コマンドライン > スクリプト定数) ----
    original_content = read_xml()
    effective_timeout = args.timeout if args.timeout is not None else DEFAULT_TRIAL_TIMEOUT
    stuck_speed_mps = STUCK_SPEED_KMH / 3.6
    stuck_duration_sec = STUCK_DURATION_SEC
    effective_target_laps = args.target_laps if args.target_laps is not None else TARGET_LAPS
    print(f"[Optuna] 上限タイムアウト: {effective_timeout}s")
    print(f"[Optuna] スタック検知: 速度 {stuck_speed_mps * 3.6:.1f} km/h 以下が "
          f"{stuck_duration_sec:.0f}s 続いたら終了")
    print(f"[Optuna] 終了周回数: {'無制限 (0)' if effective_target_laps == 0 else f'{effective_target_laps}周'}")

    # ---- 現在の control_mode を保存して rule_based に切り替え ----
    original_mode = get_control_mode(original_content)
    if original_mode != "rule_based":
        print(f"[Optuna] control_mode を '{original_mode}' → 'rule_based' に変更します。")
        write_xml(set_control_mode(original_content, "rule_based"))
    else:
        print("[Optuna] control_mode は既に 'rule_based' です。")

    try:
        # 新規実行 (--resume なし) の場合、既存スタディを削除してから作り直す
        if not args.resume:
            try:
                optuna.delete_study(
                    study_name="pure_pursuit_optimization",
                    storage=args.study_db,
                )
                print("[Optuna] 既存スタディを削除して新規作成します。")
            except Exception:
                pass  # スタディが存在しない場合は無視

        study = optuna.create_study(
            study_name="pure_pursuit_optimization",
            direction="minimize",
            storage=args.study_db,
            load_if_exists=args.resume,
        )

        existing = len([t for t in study.trials if t.state.is_finished()])
        print(f"[Optuna] 最適化開始: {args.n_trials} トライアル")
        print(f"[Optuna] 既存完了トライアル数: {existing}")
        print("[Optuna] パラメータ探索範囲:")
        for name, (lo, hi) in PARAM_RANGES.items():
            print(f"  {name}: [{lo}, {hi}]")
        print()

        if existing == 0:
            print("[Optuna] 初回トライアル: デフォルト値をベースラインとして登録します。")
            study.enqueue_trial(PARAM_DEFAULTS)

        try:
            study.optimize(
                build_objective(effective_timeout, stuck_speed_mps, stuck_duration_sec, effective_target_laps, args.dry_run),
                n_trials=args.n_trials, show_progress_bar=True,
            )
        except KeyboardInterrupt:
            print("\n[Optuna] 中断されました。")

        # ---- 結果表示 ----
        finished = [t for t in study.trials if t.state.is_finished()]
        if finished:
            best = study.best_trial
            print("\n" + "=" * 50)
            print("最適化完了")
            print("=" * 50)
            print(f"最良トライアル: #{best.number}")
            print(f"最小ラップタイム: {best.value:.3f} s")
            print("最良パラメータ:")
            for k, v in best.params.items():
                print(f"  {k}: {v:.4f}")
            print(f"\n最良パラメータを {LAUNCH_XML_PATH} に書き込みます...")
            write_params(best.params)

    finally:
        # ---- control_mode を元に戻す ----
        if original_mode != "rule_based":
            print(f"[Optuna] control_mode を '{original_mode}' に復元します。")
            content = read_xml()
            write_xml(set_control_mode(content, original_mode))


if __name__ == "__main__":
    main()
