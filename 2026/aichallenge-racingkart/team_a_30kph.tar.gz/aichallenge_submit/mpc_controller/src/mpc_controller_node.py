#!/usr/bin/env python3
"""
MPC Controller for aichallenge
Iterative Linear MPC for steering control + P control for speed.
Based on the algorithm from VML/MPC/pid_mpc_1.py (Virtual Motorsport Lab).

Steering oscillation fixes (2026-02-19):
  1. Warm-start shift : prev_od is shifted by 1 step each control cycle.
  2. Correct linearisation : each ILMPC iteration linearises the bicycle
     model around od[k] (the current iterate) instead of the fixed dref=0.
  3. Monotonic nearest-point search : index is constrained to a forward
     window around the previous nearest index to prevent back-and-forth jumps.
  4. Tighter defaults : horizon 7→15, rd_steer 800→3000, max_iter 3→5.
  5. Output low-pass filter : configurable alpha (default 1.0 = off).
"""

import math
import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy, HistoryPolicy
from autoware_auto_control_msgs.msg import AckermannControlCommand
from autoware_auto_planning_msgs.msg import Trajectory
from nav_msgs.msg import Odometry


# ─── Utility functions ────────────────────────────────────────────────────────

def quat_to_yaw(q):
    """Convert ROS quaternion to yaw angle [rad]."""
    siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
    cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
    return math.atan2(siny_cosp, cosy_cosp)


def smooth_yaw(yaw_array):
    """Remove wrap-around discontinuities from a yaw sequence."""
    for i in range(1, len(yaw_array)):
        diff = yaw_array[i] - yaw_array[i - 1]
        while diff > math.pi:
            yaw_array[i] -= 2.0 * math.pi
            diff = yaw_array[i] - yaw_array[i - 1]
        while diff < -math.pi:
            yaw_array[i] += 2.0 * math.pi
            diff = yaw_array[i] - yaw_array[i - 1]
    return yaw_array


# ─── MPC core ─────────────────────────────────────────────────────────────────

def get_linear_model_matrix(v, yaw, delta, L, dt):
    """
    Linearized kinematic bicycle model at operating point (v, yaw, delta).
    Model: x_{k+1} = A * x_k + B * u_k + C
    State: [x, y, yaw],  Input: [steer_angle]
    """
    A = np.eye(3)
    A[0, 2] = -dt * v * math.sin(yaw)
    A[1, 2] = dt * v * math.cos(yaw)

    cos2_d = math.cos(delta) ** 2
    if cos2_d < 1e-8:
        cos2_d = 1e-8
    B = np.zeros((3, 1))
    B[2, 0] = dt * v / (L * cos2_d)

    C = np.zeros(3)
    C[0] = dt * v * (math.cos(yaw) + yaw * math.sin(yaw))
    C[1] = dt * v * (math.sin(yaw) - yaw * math.cos(yaw))
    C[2] = dt * v * (math.tan(delta) - delta / cos2_d) / L

    return A, B, C


def predict_motion(x0, od, vref, T, L, max_steer, dt):
    """
    Predict state trajectory using the kinematic bicycle model.
    Returns xbar of shape (3, T+1): columns are [x_0, x_1, ..., x_T].
    """
    xbar = np.zeros((3, T + 1))
    xbar[:, 0] = x0
    x, y, yaw = x0
    for k in range(T):
        delta = np.clip(od[k], -max_steer, max_steer)
        v = vref[k]
        x = x + v * math.cos(yaw) * dt
        y = y + v * math.sin(yaw) * dt
        yaw = yaw + v * math.tan(delta) / L * dt
        xbar[:, k + 1] = [x, y, yaw]
    return xbar


def build_condensed_matrices(A_list, B_list, C_list, T):
    """
    Build condensed (batch) MPC matrices via recursion.
    x_k  = Phi * x0 + Theta * u + D    for k = 1..T
    Where X_free = [x_1; x_2; ...; x_T] (shape NX*T).
    Returns:
        Phi   (NX*T x NX)
        Theta (NX*T x T)   [NU=1, so u is length T]
        D     (NX*T,)
    """
    NX = 3
    Phi = np.zeros((NX * T, NX))
    Theta = np.zeros((NX * T, T))
    D = np.zeros(NX * T)

    phi_prev = np.eye(NX)
    theta_prev = np.zeros((NX, T))
    d_prev = np.zeros(NX)

    for k in range(T):
        Ak = A_list[k]
        bk = B_list[k].flatten()   # shape (NX,)
        ck = C_list[k]

        phi_k = Ak @ phi_prev
        theta_k = Ak @ theta_prev
        theta_k[:, k] = bk          # add B_k * u_k contribution
        d_k = Ak @ d_prev + ck

        Phi[k * NX:(k + 1) * NX, :] = phi_k
        Theta[k * NX:(k + 1) * NX, :] = theta_k
        D[k * NX:(k + 1) * NX] = d_k

        phi_prev = phi_k
        theta_prev = theta_k
        d_prev = d_k

    return Phi, Theta, D


def solve_mpc(x0, xref, vref, od_init,
              T, Q, Qf, R_val, Rd_val,
              L, max_steer, steer_margin, dt,
              max_iter=5, du_th=0.12):
    """
    Iterative linear MPC for steering control (NU=1, NX=3).

    Minimises:
      sum_{k=1}^{T-1} (x_k - xref_k)' Q (x_k - xref_k)
      + (x_T - xref_T)' Qf (x_T - xref_T)
      + sum_{k=0}^{T-1} u_k^2 * R_val
      + sum_{k=0}^{T-2} (u_k - u_{k+1})^2 * Rd_val

    subject to: -max_steer+steer_margin <= u_k <= max_steer-steer_margin

    Fix: linearise around od[k] at each iteration (not fixed dref=0).

    Returns optimal steering sequence od (length T).
    """
    NX = 3
    if od_init is None:
        od = np.zeros(T)
    else:
        od = od_init.copy()

    # Build Q_bar: block_diag([Q]*(T-1), [Qf])  → applied to [x_1..x_{T-1}, x_T]
    Q_bar = np.zeros((NX * T, NX * T))
    for k in range(T - 1):
        Q_bar[k * NX:(k + 1) * NX, k * NX:(k + 1) * NX] = Q
    Q_bar[(T - 1) * NX:T * NX, (T - 1) * NX:T * NX] = Qf

    # Input difference cost matrix S_d = Rd * M' M
    M = np.zeros((T - 1, T))
    for i in range(T - 1):
        M[i, i] = 1.0
        M[i, i + 1] = -1.0
    S_d = Rd_val * (M.T @ M)

    # Input cost matrix R_bar
    R_bar = R_val * np.eye(T)

    # Reference vector [xref_1; xref_2; ...; xref_T]
    xref_free = np.concatenate([xref[:, k + 1] for k in range(T)])

    for _ in range(max_iter):
        xbar = predict_motion(x0, od, vref, T, L, max_steer, dt)
        pod = od.copy()

        # FIX: linearise around od[k] (current iterate), not fixed dref=0
        A_list, B_list, C_list = [], [], []
        for k in range(T):
            A, B, C = get_linear_model_matrix(
                vref[k], xbar[2, k], od[k], L, dt)
            A_list.append(A)
            B_list.append(B)
            C_list.append(C)

        # Condensed matrices
        Phi, Theta, D = build_condensed_matrices(A_list, B_list, C_list, T)

        # Error term e = Phi*x0 + D - Xref_free
        e = Phi @ x0 + D - xref_free

        # Hessian and gradient
        H = Theta.T @ Q_bar @ Theta + R_bar + S_d
        H += 1e-6 * np.eye(T)          # numerical regularisation
        f = Theta.T @ Q_bar @ e

        # Solve unconstrained QP: H*u = -f
        try:
            od_new = np.linalg.solve(H, -f)
        except np.linalg.LinAlgError:
            break

        # Apply steering constraints
        od_new = np.clip(od_new,
                         -max_steer + steer_margin,
                         max_steer - steer_margin)

        du = np.sum(np.abs(od_new - pod))
        od = od_new
        if du <= du_th:
            break

    return od


# ─── ROS2 node ────────────────────────────────────────────────────────────────

class MPCController(Node):
    def __init__(self):
        super().__init__('mpc_controller')

        # MPC parameters
        self.T = self.declare_parameter('horizon', 15).value
        self.DT = self.declare_parameter('dt', 0.1).value
        self.wheel_base = self.declare_parameter('wheel_base', 2.14).value
        self.MAX_STEER = math.radians(
            self.declare_parameter('max_steer_deg', 35.0).value)
        self.STEER_MARGIN = math.radians(
            self.declare_parameter('steer_margin_deg', 10.0).value)
        self.max_iter = self.declare_parameter('max_iter', 5).value
        self.du_th = self.declare_parameter('du_th', 0.12).value

        # Cost weight matrices
        q_x   = self.declare_parameter('q_x',   3.0).value
        q_y   = self.declare_parameter('q_y',   3.0).value
        q_yaw = self.declare_parameter('q_yaw', 1.0).value
        qf_x   = self.declare_parameter('qf_x',   4.0).value
        qf_y   = self.declare_parameter('qf_y',   4.0).value
        qf_yaw = self.declare_parameter('qf_yaw', 1.2).value
        self.Q  = np.diag([q_x, q_y, q_yaw])
        self.Qf = np.diag([qf_x, qf_y, qf_yaw])
        self.R_val  = self.declare_parameter('r_steer',  300.0).value
        self.Rd_val = self.declare_parameter('rd_steer', 3000.0).value

        # Speed / steering output parameters
        self.speed_proportional_gain = self.declare_parameter(
            'speed_proportional_gain', 1.0).value
        self.use_external_target_vel = self.declare_parameter(
            'use_external_target_vel', False).value
        self.external_target_vel = self.declare_parameter(
            'external_target_vel', 0.0).value
        self.steering_tire_angle_gain = self.declare_parameter(
            'steering_tire_angle_gain', 1.0).value

        # Output low-pass filter (alpha=1.0 → no filter; smaller = smoother)
        self.steer_lpf_alpha = self.declare_parameter('steer_lpf_alpha', 1.0).value

        # Internal state
        self.odometry_ = None
        self.trajectory_ = None
        self.prev_od = None       # warm-start: previous steering sequence (shifted)
        self.prev_ind = 0         # FIX: monotonic nearest-point index
        self.prev_steer = 0.0     # FIX: low-pass filter state

        # QoS (matches Autoware convention)
        bv_qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            durability=DurabilityPolicy.VOLATILE,
            history=HistoryPolicy.KEEP_LAST,
            depth=1,
        )

        self.sub_kinematics = self.create_subscription(
            Odometry, 'input/kinematics',
            lambda msg: setattr(self, 'odometry_', msg), bv_qos)
        self.sub_trajectory = self.create_subscription(
            Trajectory, 'input/trajectory',
            lambda msg: setattr(self, 'trajectory_', msg), bv_qos)

        self.pub_cmd = self.create_publisher(
            AckermannControlCommand, 'output/control_cmd', 1)

        # Control loop at 10 ms (100 Hz)
        self.timer = self.create_timer(0.01, self.on_timer)

        self.get_logger().info('MPC Controller initialised')

    # ── Reference trajectory extraction ──────────────────────────────────────

    def calc_ref_trajectory(self, x_cur, y_cur, pts):
        """
        Extract T+1 reference states from the trajectory message.

        FIX: nearest-point search is constrained to a forward window around
        self.prev_ind to prevent back-and-forth index jumps that cause
        steering oscillation.

        Returns:
            xref  (3 x T+1)   – reference [x, y, yaw]
            ind   (int)        – index of nearest point (updated)
            vref  (T+1,)       – reference speed
        """
        n = len(pts)
        T = self.T
        DT = self.DT

        # FIX: search only in a forward window [prev_ind-5, prev_ind+30]
        search_back = 5
        search_fwd  = 30
        i_lo = self.prev_ind
        i_hi = (self.prev_ind + search_fwd) % n
        if i_hi > i_lo:
            candidates = list(range(i_lo, i_hi))
        else:
            candidates = list(range(i_lo, n)) + list(range(0, i_hi))
        # also allow a small backward window to recover from rare jumps
        back_candidates = [
            (self.prev_ind - j) % n for j in range(1, search_back + 1)
        ]
        candidates = back_candidates + candidates

        positions = np.array([[pts[i].pose.position.x,
                                pts[i].pose.position.y] for i in candidates])
        dists = np.hypot(positions[:, 0] - x_cur, positions[:, 1] - y_cur)
        best = int(np.argmin(dists))
        ind = candidates[best]
        self.prev_ind = ind

        # Average point spacing
        all_positions = np.array([[p.pose.position.x,
                                    p.pose.position.y] for p in pts])
        diffs = np.diff(all_positions, axis=0)
        dl = np.mean(np.hypot(diffs[:, 0], diffs[:, 1]))
        if dl < 1e-6:
            dl = 1.0

        xref = np.zeros((3, T + 1))
        vref = np.zeros(T + 1)

        pt0 = pts[ind]
        xref[0, 0] = pt0.pose.position.x
        xref[1, 0] = pt0.pose.position.y
        xref[2, 0] = quat_to_yaw(pt0.pose.orientation)
        vref[0] = pt0.longitudinal_velocity_mps

        travel = 0.0
        for i in range(1, T + 1):
            travel += abs(vref[i - 1]) * DT
            dind = int(round(travel / dl))
            idx = (ind + dind + 1) % n
            pt = pts[idx]
            xref[0, i] = pt.pose.position.x
            xref[1, i] = pt.pose.position.y
            xref[2, i] = quat_to_yaw(pt.pose.orientation)
            vref[i] = pt.longitudinal_velocity_mps

        xref[2, :] = smooth_yaw(xref[2, :])
        return xref, ind, vref

    # ── Control loop ─────────────────────────────────────────────────────────

    def on_timer(self):
        if self.odometry_ is None or self.trajectory_ is None:
            return
        if len(self.trajectory_.points) == 0:
            return

        # Current state
        pos = self.odometry_.pose.pose.position
        x_cur = pos.x
        y_cur = pos.y
        yaw_cur = quat_to_yaw(self.odometry_.pose.pose.orientation)
        v_cur = self.odometry_.twist.twist.linear.x

        # Reference trajectory
        pts = self.trajectory_.points
        xref, ind, vref = self.calc_ref_trajectory(x_cur, y_cur, pts)

        # Align yaw to reference (avoid ±π jumps)
        if yaw_cur - xref[2, 0] >= math.pi:
            yaw_cur -= 2.0 * math.pi
        elif yaw_cur - xref[2, 0] <= -math.pi:
            yaw_cur += 2.0 * math.pi
        x0 = np.array([x_cur, y_cur, yaw_cur])

        # FIX: warm-start with properly shifted previous solution
        if self.prev_od is not None:
            od_init = np.append(self.prev_od[1:], self.prev_od[-1])
        else:
            od_init = None

        # Solve MPC (dref removed; linearisation uses od[k] internally)
        od = solve_mpc(
            x0, xref, vref, od_init,
            self.T, self.Q, self.Qf, self.R_val, self.Rd_val,
            self.wheel_base, self.MAX_STEER, self.STEER_MARGIN,
            self.DT, self.max_iter, self.du_th,
        )

        # FIX: store shifted warm-start for next cycle
        self.prev_od = od

        # Raw steering command
        raw_steer = float(np.clip(
            self.steering_tire_angle_gain * od[0],
            -self.MAX_STEER, self.MAX_STEER))

        # FIX: output low-pass filter (alpha=1.0 → no filter)
        steer_cmd = (self.steer_lpf_alpha * raw_steer
                     + (1.0 - self.steer_lpf_alpha) * self.prev_steer)
        self.prev_steer = steer_cmd

        # Speed command (proportional control)
        target_vel = (self.external_target_vel
                      if self.use_external_target_vel
                      else float(vref[0]))
        speed_accel = float(self.speed_proportional_gain * (target_vel - v_cur))

        # Publish
        cmd = AckermannControlCommand()
        now = self.get_clock().now().to_msg()
        cmd.stamp = now
        cmd.longitudinal.stamp = now
        cmd.lateral.stamp = now
        cmd.longitudinal.speed = target_vel
        cmd.longitudinal.acceleration = speed_accel
        cmd.lateral.steering_tire_angle = steer_cmd
        self.pub_cmd.publish(cmd)


# ─── Entry point ──────────────────────────────────────────────────────────────

def main(args=None):
    rclpy.init(args=args)
    node = MPCController()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
