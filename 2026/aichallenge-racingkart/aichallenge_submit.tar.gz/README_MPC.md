# MPC 設定ガイド

## 1. 制御方式の選択

[reference.launch.xml](../workspace/src/aichallenge_submit/aichallenge_submit_launch/launch/reference.launch.xml) の L20 で制御方式を指定する。

```xml
<arg name="control_method" default="mpc"
     description="Select control: mpc, pure_pursuit, tiny_lidar_net, joycon"/>
```

`mpc` がデフォルトなので、通常は変更不要。

---

## 2. MPC の理論

### 2.1 基本的な考え方

MPC（Model Predictive Control / モデル予測制御）は、**「先の状態を予測しながら、その都度"いちばん良さそうな操作列"を解く制御」** である。

毎制御周期ごとに以下を繰り返す：

1. 今の状態を測る（もしくは推定する）
2. モデルを使って、未来 **N ステップ分**の状態の動きを予測する
3. 「コスト関数」を最小にするような操作入力列 $(u_0, \dots, u_{N-1})$ を最適化問題として解く（制約付き最適化）
4. 解いた操作列のうち **最初の1ステップ分の入力だけ**を実機に与える（残りは捨てる）
5. 1サイクル後にまた状態を測り直して、1〜4を繰り返す

この「毎回先読みして最適化 → 最初の一手だけ打って残りは捨てる」という仕組みを **Receding Horizon（後退ホライゾン）制御** と呼ぶ。これがMPCの核である。

**自動運転にMPCが使われる理由:**
- 未来の軌跡（路面ジオメトリや経路）を使って、**先を見越した操作**ができる（コーナー手前からステア・減速）
- 車両の物理制約（最大舵角・横加速度・道幅など）を「制約」として素直に入れられる
- コストの重み Q・R を調整することで、「キビキビ vs ふんわり」「なるべく経路中央 vs 多少左右を使ってもスムーズ」など走行"性格"をチューニングできる

### 2.2 数式レベルの基本形（一般的なMPC）

一般的なMPCでは、離散時間線形モデルを使う標準形が基本となる：

**システムモデル:**
$$x_{k+1} = A x_k + B u_k$$

（自動運転だと、状態 $x_k$ に位置・速度・ヨーレートを、入力 $u_k$ にステア・アクセルなどを含めるイメージ）

**コスト関数（予測ホライズン N）:**
$$J = \sum_{i=0}^{N-1} \left[ (x_{k+i} - x_{\text{ref}})^\top Q (x_{k+i} - x_{\text{ref}}) + u_{k+i}^\top R\, u_{k+i} \right] + (x_{k+N} - x_{\text{ref}})^\top Q_N (x_{k+N} - x_{\text{ref}})$$

- **Q**：目標状態からのずれをどれだけ嫌うか（追従重視 → 大きく）
- **R**：操作量の大きさをどれだけ嫌うか（急ハンドル・急加減速を抑える → 大きく、ただし応答が遅れる）
- **$Q_N$**：ホライゾン終端の状態誤差コスト（安定性に影響）
- **N**：予測ホライズン（何ステップ先まで見るか）

「2乗和のコスト＋線形モデル＋線形制約」の組み合わせにより、**二次計画問題（QP）** として高速に解ける。本実装では **OSQPソルバー** を使用している。

> **まず押さえるべきパラメータ（直感):**
> - **Q が大きい** → 軌跡に強く張り付こうとする（追従重視）
> - **R が大きい** → 操作が穏やかで滑らかだが応答は遅い
> - **N が大きい** → 先読みが効くが計算コストが増大

---

### 2.3 この実装の特徴（標準MPCとの違い）

この実装は一般的なMPCと以下の点が異なる：

| 項目 | 一般的なMPC | この実装 |
|---|---|---|
| 座標系 | ワールド座標 (x, y, psi) | **Frenet（曲線）座標系** |
| モデル | 固定の線形モデル (A, B) | **LTV（線形時変）**: 各ウェイポイントで行列が変わる |
| 速度制限 | 入力制約のみ | **曲率ベースの動的速度制限** (ay_max) を追加 |
| ソルバー | 各種 | **OSQP** |

---

### 2.4 状態空間表現（Frenet座標系）

このMPCは、参照経路上の**Frenet（曲線）座標系**で車両状態を表現する。

```
状態ベクトル: x = [e_y, e_psi, t]
```

| 変数 | 意味 | 単位 |
|---|---|---|
| `e_y` | 参照経路からの横方向偏差（左が正） | m |
| `e_psi` | 参照経路に対する相対ヨー角（左旋回が正） | rad |
| `t` | 時間（コスト計算に使用） | s |

```
入力ベクトル: u = [v, delta]
```

| 変数 | 意味 | 単位 |
|---|---|---|
| `v` | 車速指令 | m/s |
| `delta` | ステアリングタイヤ角（曲率 kappa = tan(delta)/L） | rad |

### 2.3 自転車モデル（Bicycle Model）の線形化

車両を**運動学的自転車モデル**で表現し、各ウェイポイント周りで**線形時変（LTV）近似**する。

Frenet座標系での離散化方程式：

```
e_y[k+1]   = e_y[k] + delta_s * e_psi[k]
e_psi[k+1] = e_psi[k] - kappa_ref^2 * delta_s * e_y[k] + delta_s * delta[k]
t[k+1]     = t[k] - (kappa_ref / v_ref) * delta_s * e_y[k] - (1/v_ref^2) * delta_s * v[k] + 1/v_ref * delta_s
```

ここで `delta_s` は隣接ウェイポイント間距離、`kappa_ref` は参照経路の曲率。

### 2.4 最適化問題（QP問題）

OSQPソルバーにより以下の2次計画問題を解く：

```
最小化: sum_{k=0}^{N-1} [ x[k]^T Q x[k] + u[k]^T R u[k] ] + x[N]^T QN x[N]

制約条件:
  - 車両ダイナミクス（等式制約）
  - 走行可能幅（横偏差制限、不等式制約）
  - 速度制限 v ∈ [0, v_max]
  - 曲率による速度上限 v <= sqrt(ay_max / |kappa|)
  - ステア角制限 |delta| <= delta_max
  - ステアレート制限 |delta[k+1] - delta[k]| <= steer_rate_max * Ts
```

- **Q**: 各ステップの状態コスト（追従精度の重み）
- **QN**: ホライゾン終端の状態コスト（安定性の重み）
- **R**: 入力コスト（制御入力の大きさへのペナルティ）

### 2.5 コーナー速度制限の仕組み（ay_max）

```
v_limit = sqrt(ay_max / |kappa_pred|)
```

- `kappa_pred`: 前方ホライゾン内の**最大曲率**（`use_max_kappa_pred: true`の場合）
- コーナーに近づくと自動的に速度上限が下がり、安全な速度で曲がれるようになる
- `use_max_kappa_pred: false`にすると現在ステップの曲率のみを使用（応答が速いが不安定になりやすい）

---

## 3. パラメータ変更場所

**メインファイル:** [multi_purpose_mpc_ros/config/config.yaml](../workspace/src/aichallenge_submit/multi_purpose_mpc_ros/config/config.yaml)

---

## 4. 速度・コーナリング限界パラメータ

### 4.1 v_max（最大速度）

```yaml
mpc:
  v_max: 15.0   # km/h
```

| 説明 | 直線での速度上限 |
|---|---|
| 単位 | km/h |
| 変更範囲 | 10.0 〜 30.0 |
| 注意 | ay_max も合わせて調整しないとコーナーで詰まる |

### 4.2 ay_max（最大横加速度）

```yaml
mpc:
  ay_max: 5.5   # m/s²
```

| 説明 | コーナリング時の速度制限に使う横加速度の上限 |
|---|---|
| 単位 | m/s² |
| 変更範囲 | 4.0 〜 12.0 |
| 小さいと | コーナーで速度が大きく下がる（安全だがタイムが落ちる） |
| 大きいと | コーナーを速く曲がれるが、グリップを超えるとスピン |

**実績値:**

| 設定 | v_max | ay_max | Lap1 | Lap2 | 状態 |
|---|---|---|---|---|---|
| 究極 | 30.0 km/h | 12.0 m/s² | 53s | 47s | 未検証 |
| 高速 | 30.0 km/h | 9.5 m/s² | 55s | 49s | 未検証 |
| 中高速 | 25.0 km/h | 7.0 m/s² | 59s | 54s | 未検証 |
| 中速（現在） | 20.0 km/h | 6.5 m/s² | 67s | 64s | ⚠️ 後半180度コーナーで曲がれず問題あり |
| 低速 | 15.0 km/h | 5.5 m/s² | 86s | - | ✅ 完走確認済み |

---

## 5. コスト重み行列パラメータ

### 5.1 Q（状態コスト重み）

```yaml
mpc:
  Q: [5000000.0, 100000000.0, 200000.0]  # [e_y, e_psi, t]
```

各要素の意味：

| インデックス | 変数 | 効果 |
|---|---|---|
| Q[0] = e_y | 横偏差のコスト | 大きいほど参照経路の中心に張り付く |
| Q[1] = e_psi | ヨー角偏差のコスト | 大きいほど参照経路の向きに揃えようとする |
| Q[2] = t | 時間コスト（速度追従） | 大きいほど参照速度に追従する |

**チューニングの考え方:**

- **コーナーで外に膨らむ場合**: Q[0]（e_y）を大きくする
- **コーナーで向きが合わない場合**: Q[1]（e_psi）を大きくする
- **速度が参照値に追従しない場合**: Q[2]（t）を大きくする
- **インを攻めすぎて壁に当たる場合**: Q[0]を大きくして中心に引き戻す（または下げてラインを逃がす）

変更範囲の目安：

| 変数 | 低速（〜20km/h） | 高速（〜30km/h） |
|---|---|---|
| Q[0] e_y | 1e5 〜 5e6 | 6e5 〜 1e6 |
| Q[1] e_psi | 5e7 〜 1e8 | 1e8 |
| Q[2] t | 1e5 〜 5e5 | 8e5 〜 2e6 |

### 5.2 QN（終端コスト重み）

```yaml
mpc:
  QN: [1000000.0, 1000.0, 10000.0]  # [e_y, e_psi, t]
```

| 説明 | ホライゾン終端（N ステップ先）の状態コスト。安定性に影響 |
|---|---|
| 変更範囲 | 各要素 1e3 〜 1e7 |
| 大きいと | 遠い先の誤差を重視するため、予測が保守的になる |
| 小さいと | 終端での追従精度を気にしなくなる |

### 5.3 R（入力コスト重み）

```yaml
mpc:
  R: [100000.0, 0.0]   # [v, delta]
```

| インデックス | 変数 | 効果 |
|---|---|---|
| R[0] = v | 速度変化のコスト | 大きいほど急加減速を避ける |
| R[1] = delta | ステア角のコスト | 大きいほど大きなステア指令を避ける（通常0で問題ない） |

| 変数 | 変更範囲 | 備考 |
|---|---|---|
| R[0] | 1e4 〜 1e6 | 大きすぎると速度追従が遅くなる |
| R[1] | 0.0 〜 1e4 | 通常は0。振動的なステアが出たら増やす |

---

## 6. ホライゾン・制御周期パラメータ

### 6.1 N（予測ホライゾン長）

```yaml
mpc:
  N: 20   # ステップ数
```

| 説明 | 何ステップ先まで予測して最適化するか |
|---|---|
| 変更範囲 | 10 〜 40 |
| 大きいと | 遠くまで先読みするのでコーナーへの準備が早くなる。ただし計算負荷が増大 |
| 小さいと | 計算が速いが先読みが短くコーナー手前で急減速しやすい |

実際の先読み距離 = N × resolution（m）。例：N=20、resolution=0.6 → 12m先まで予測。

### 6.2 control_rate（制御周波数）

```yaml
mpc:
  control_rate: 40.0   # Hz
```

| 説明 | MPCの計算・コマンド送信頻度 |
|---|---|
| 変更範囲 | 20.0 〜 50.0 |
| 高いほど | 遅れが少なく応答性が良いが計算負荷が増大 |
| 低いほど | 計算は楽だが制御遅れが増す |

---

## 7. 制約パラメータ

### 7.1 a_min / a_max（加速度制限）

```yaml
mpc:
  a_min: -1.6   # m/s²（減速限界）
  a_max:  0.7   # m/s²（加速限界）
```

| 説明 | 縦方向の加速度の上下限 |
|---|---|
| a_min 変更範囲 | -3.0 〜 -0.5 |
| a_max 変更範囲 | 0.3 〜 2.0 |
| a_min を大きくする（-0.5方向） | 急ブレーキが弱くなる。コーナー前で速度が落ちきらない |
| a_min を小さくする（-3.0方向） | 急ブレーキが強くなる。コーナーギリギリまで全開できる |

### 7.2 delta_max_deg（最大ステア角）

```yaml
mpc:
  delta_max_deg: 32.0   # degrees
```

| 説明 | タイヤの最大切れ角 |
|---|---|
| 変更範囲 | 20.0 〜 40.0 |
| 注意 | 実機の物理的な限界値に合わせる。大きすぎると実機でサチる |

### 7.3 steer_rate_max（ステアレート制限）

```yaml
mpc:
  steer_rate_max: 0.35   # rad/s
```

| 説明 | 1秒間に変化できるステア角の最大値 |
|---|---|
| 変更範囲 | 0.1 〜 1.0 |
| 小さいと | ステアリングがゆっくり動く。急な切り返しができないが滑らかになる |
| 大きいと | 素早いステアが可能だが、振動的な入力が増える可能性がある |

---

## 8. フィルタ・遅延補償パラメータ

### 8.1 steering_tire_angle_gain_var（ステアゲイン補正）

```yaml
mpc:
  steering_tire_angle_gain_var: 1.639
```

| 説明 | MPCが出すステア指令に対して実際のタイヤ角がずれている場合の補正ゲイン |
|---|---|
| 変更範囲 | 0.8 〜 2.0 |
| > 1.0 | 実機のタイヤが指令より小さく切れている → 指令を増幅して補正 |
| < 1.0 | 実機のタイヤが指令より大きく切れている → 指令を縮小して補正 |
| チューニング方法 | 直線で微小ステアを入れて、実機の切れ角との比率を確認する |

### 8.2 accel_low_pass_gain（アクセルローパスフィルタゲイン）

```yaml
mpc:
  accel_low_pass_gain: 1.0
```

| 説明 | アクセル出力のローパスフィルタゲイン |
|---|---|
| 変更範囲 | 0.05 〜 1.0 |
| 1.0 | フィルタなし（現在値をそのまま使用） |
| 0.1 | 強いフィルタ。出力 = 0.1×新値 + 0.9×前回値。速度変化がなめらかになる |
| 小さいと | 急激な速度変化が抑制される。ただし応答が遅れる |

### 8.3 steer_low_pass_gain（ステアローパスフィルタゲイン）

```yaml
mpc:
  steer_low_pass_gain: 1.0
```

| 説明 | ステア出力のローパスフィルタゲイン |
|---|---|
| 変更範囲 | 0.05 〜 1.0 |
| 1.0 | フィルタなし |
| 0.3 | 中程度のフィルタ。ステアリングのガタつきが減る |
| 小さいと | ステアが滑らかになるが応答が遅れ、コーナーで追従が遅くなる |

### 8.4 wp_id_offset（制御遅延補償）

```yaml
mpc:
  wp_id_offset: 2
```

| 説明 | 制御遅延（通信・計算遅延）を補償するために参照ウェイポイントをずらすオフセット |
|---|---|
| 変更範囲 | 0 〜 5 |
| 大きいと | 遅延が大きいシステム向け。コーナー手前での操舵開始が早くなる |
| 小さいと | 遅延が小さいシステム向け。大きすぎると先読みしすぎて振動する |
| チューニング方法 | コーナーで常に外に膨らむなら増やす。振動・蛇行が出たら減らす |

---

## 9. 車両モデルパラメータ

**ファイル:** [config.yaml](../workspace/src/aichallenge_submit/multi_purpose_mpc_ros/config/config.yaml)

```yaml
bicycle_model:
  length: 1.087   # ホイールベース [m]
  width: 2.30     # 安全マージン込みの幅 [m]
```

| パラメータ | 説明 | 変更範囲 |
|---|---|---|
| `length` | 前後輪間距離（ホイールベース）。ステア→曲率変換に使用 | 実機の実測値に合わせる |
| `width` | 走行可能幅の制約に使うモデル幅。実機幅 + 安全マージン | 実機幅（1.45m）〜 3.0m |

> 安全マージンの計算: `safety_margin = width / sqrt(2)`
> width を大きくすると走行可能幅の余裕が減り、コーナーのラインが制約される。

---

## 10. 参照経路パラメータ

```yaml
reference_path:
  csv_path: "env/final_ver3/traj_mincurv6.csv"
  resolution: 0.6        # m
  smoothing_distance: 2  # ウェイポイント数
  max_width: 6.0         # m
  circular: true
```

| パラメータ | 説明 | 変更範囲 |
|---|---|---|
| `resolution` | ウェイポイント間隔 [m] | 0.3 〜 1.0 |
| `smoothing_distance` | 経路スムージングのカーネル幅 [ウェイポイント数] | 1 〜 5 |
| `max_width` | 走行可能幅の最大値 [m] | 3.0 〜 8.0 |

**resolution の影響:**
- 小さいほど経路が細かく精度が上がる。ただし計算量が増え、Nステップ先の実距離が短くなる
- `resolution: 0.6`、`N: 20` → 先読み距離 = 12m

---

## 11. mpc.launch.xml の ROSパラメータ

**ファイル:** [aichallenge_submit_launch/launch/control/mpc.launch.xml](../workspace/src/aichallenge_submit/aichallenge_submit_launch/launch/control/mpc.launch.xml)

```xml
<param name="use_boost_acceleration" value="false"/>
<param name="use_obstacle_avoidance" value="false"/>
<param name="use_stats" value="false"/>
```

| パラメータ | 効果 |
|---|---|
| `use_boost_acceleration` | ブースト加速機能の有効化 |
| `use_obstacle_avoidance` | `/aichallenge/objects` トピックの障害物を考慮した経路制約の有効化 |
| `use_stats` | 実行統計のログ出力 |

---

## 12. Trajectory の変更場所

**2箇所あり、`update_by_topic` の設定によって使い分ける。**

### パターン A: config.yaml でCSVを直接指定（現在の設定）

`update_by_topic: false` のとき、MPC は config.yaml の `csv_path` を使用する。

**ファイル:** [multi_purpose_mpc_ros/config/config.yaml](../workspace/src/aichallenge_submit/multi_purpose_mpc_ros/config/config.yaml)

```yaml
reference_path:
  update_by_topic: true   # falseのときこのcsvを使用
  csv_path: "env/final_ver3/traj_mincurv6.csv"  # pkg share からの相対パス
  resolution: 0.6
  smoothing_distance: 2
  max_width: 6.0
  circular: true
```

### パターン B: simple_trajectory_generator のトピック経由

`update_by_topic: true` にすると、`simple_trajectory_generator` がパブリッシュするトピックからtrajectoryを受け取る。

このときは [reference.launch.xml L126](../workspace/src/aichallenge_submit/aichallenge_submit_launch/launch/reference.launch.xml) の `csv_path` を変更する。

```xml
<node pkg="simple_trajectory_generator" exec="simple_trajectory_generator_node" name="simple_trajectory_generator" output="screen">
    <param name="csv_path" value="$(find-pkg-share simple_trajectory_generator)/data/raceline_awsim_30km_from_garage.csv"/>
    <param name="z" value="6.5"/>
</node>
```

利用可能なCSVファイル（`simple_trajectory_generator/data/` 配下）:

- `raceline_awsim_30km_from_garage.csv`（現在設定中）
- `raceline_2026_mincurv4.csv`
- `raceline_2026_mincurv5.csv`
- `raceline_2026_mincurv5_2.csv`
- `raceline_2026_mincurv5_2_updated.csv`
- `raceline_2026_mincurv6.csv`
- `raceline_2026_mincurv6_MPC.csv`（MPC専用）
- `raceline_cctb_30km_wide.csv`
- `raceline_cctb_30km_wide_from_garage.csv`
- `raceline_cctb_30km_wide_from_garage_yutori.csv`
- `raceline_cctb_30km.csv`
- `raceline_from_garage.csv`
- `raceline_from_garage_ReRoute.csv`
- `raceline_from_garage_ReRoute_ReQx.csv`
- `raceline_awsim_15km.csv`

> **注意:** 現在 `update_by_topic: false` のため、`simple_trajectory_generator` のCSVはMPCに影響していない。

---

## 13. チューニング手順の例

### 13.1 速度を上げたい場合

1. `v_max` を段階的に上げる（例: 15 → 20 → 25 km/h）
2. コーナーで詰まるなら `ay_max` も上げる（例: 5.5 → 7.0 m/s²）
3. コーナー追従がずれるなら Q[0]（e_y）か wp_id_offset を調整
4. 振動が出たら `steer_rate_max` または `steer_low_pass_gain` を下げる

### 13.2 コーナーでの追従を改善したい場合

| 症状 | 対処 |
|---|---|
| コーナーで外に膨らむ | Q[0]（e_y）を増やす、wp_id_offset を増やす |
| コーナーで向きが合わない | Q[1]（e_psi）を増やす |
| コーナー前に速度が落ちすぎ | ay_max を増やす |
| コーナー前に速度が落ちない | ay_max を減らす、a_min を小さくする |
| ステアがガタつく・振動する | steer_low_pass_gain を下げる、steer_rate_max を減らす |
| 直線で蛇行する | wp_id_offset を減らす、Q[1]を増やす |

### 13.3 低速設定（✅ 完走確認済み）

```yaml
mpc:
  v_max: 15.0
  ay_max: 5.5
  N: 20
  Q: [5000000.0, 100000000.0, 200000.0]
  QN: [1000000.0, 1000.0, 10000.0]
  R: [100000.0, 0.0]
  a_min: -1.6
  a_max: 0.7
  delta_max_deg: 32.0
  steer_rate_max: 0.35
  wp_id_offset: 2
  accel_low_pass_gain: 1.0
  steer_low_pass_gain: 1.0
```

### 13.4 中速設定（⚠️ 後半180度コーナーで曲がれず問題あり）

```yaml
mpc:
  v_max: 20.0
  ay_max: 6.5
  N: 20
  Q: [3000000.0, 90000000.0, 100000.0]
  QN: [1000000.0, 1000.0, 10000.0]
  R: [100000.0, 0.0]
  a_min: -1.6
  a_max: 0.7
  delta_max_deg: 32.0
  steer_rate_max: 0.35
  wp_id_offset: 2
  accel_low_pass_gain: 1.0
  steer_low_pass_gain: 1.0
```

**問題:** 後半の180度コーナーで曲がりきれない。

**原因の候補と対処:**

| 原因候補 | 対処 |
|---|---|
| コーナー前の速度が高すぎる | `ay_max` を 6.5 → 5.5〜6.0 に下げる |
| 先読みが足りずコーナーへの制動が遅い | `N` を 20 → 25〜30 に増やす |
| コーナーで向きが合っていない | `Q[1]`（e_psi）を 9e7 → 1e8 に上げる |
| コーナー直前の減速が弱い | `a_min` を -1.6 → -2.0 に下げる |

---

## 14. パラメータ早見表

| パラメータ | 現在値 | 変更範囲 | 大きくすると | 小さくすると |
|---|---|---|---|---|
| `v_max` | 15.0 km/h | 10〜30 | 速くなる | 遅くなる |
| `ay_max` | 5.5 m/s² | 4〜12 | コーナーが速い（危険） | コーナーが遅い（安全） |
| `N` | 20 | 10〜40 | 先読み長い・計算重い | 先読み短い・計算軽い |
| `Q[0]` e_y | 5e6 | 1e5〜1e7 | 中心に張り付く | ラインが自由 |
| `Q[1]` e_psi | 1e8 | 1e7〜1e8 | 向きを揃える | 向きが自由 |
| `Q[2]` t | 2e5 | 1e4〜2e6 | 速度追従が強い | 速度が自由 |
| `R[0]` v | 1e5 | 1e4〜1e6 | 加減速が穏やか | 加減速が激しい |
| `a_min` | -1.6 m/s² | -3〜-0.5 | 急ブレーキ可 | ブレーキが弱い |
| `a_max` | 0.7 m/s² | 0.3〜2.0 | 急加速可 | 加速が穏やか |
| `delta_max_deg` | 32.0 deg | 20〜40 | 急旋回可 | 最大切れ角が小さい |
| `steer_rate_max` | 0.35 rad/s | 0.1〜1.0 | 素早いステア | ゆっくりステア |
| `wp_id_offset` | 2 | 0〜5 | 先のWPを参照・早め操舵 | 現在WP参照 |
| `accel_low_pass_gain` | 1.0 | 0.05〜1.0 | 応答が速い | 加速が滑らか |
| `steer_low_pass_gain` | 1.0 | 0.05〜1.0 | 応答が速い | ステアが滑らか |
| `steering_tire_angle_gain_var` | 1.639 | 0.8〜2.0 | ステア指令を増幅 | ステア指令を縮小 |
